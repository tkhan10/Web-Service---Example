package com.tofek.auth.LoginAndRegister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAndRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAndRegisterApplication.class, args);
	}

}
