package com.tofek.auth.LoginAndRegister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAndRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
