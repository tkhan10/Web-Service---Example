/**
 * 
 */
package com.tofek.db.DBWishlist.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.tofek.db.DBWishlist.Utils.ExcelUtils;
import com.tofek.db.DBWishlist.model.UserInfo;
import com.tofek.db.DBWishlist.model.Wish;

/**
 * @author tkhan26
 *
 */
public class DBWishlistService {

	private static Map<Integer, Wish> wishlistMap = new HashMap<Integer, Wish>();
	private static Map<Integer, UserInfo> userRegisterMap = new HashMap<Integer, UserInfo>();
	
	ExcelUtils dataStore = new ExcelUtils();
	

	public List<Wish> getWishlist() {
		List<Wish> list = wishlistMap.values().stream().filter(x -> x.isActive()).collect(Collectors.toList());
		//dataStore.addWishIntoList();
		
		return list;

	}

	public boolean addWish(Wish wish) {
		/*
		 * System.out.println("DB Service Added");
		 * 
		 * if (wishlistMap.size() > 0) { Integer key = findHigestKey();
		 * wish.setWishId(key + 1); wishlistMap.put(key + 1, wish); } else {
		 * wish.setWishId(1000); wishlistMap.put(1000, wish); }
		 */
		
		dataStore.addWishIntoList(wish);
		//dataStore.getWishIntoList();

		return true;

	}

	/**
	 * @return
	 */
	private Integer findHigestKey() {
		Integer key = Collections.max(wishlistMap.entrySet(), new Comparator<Entry<Integer, Wish>>() {

			@Override
			public int compare(Entry<Integer, Wish> o1, Entry<Integer, Wish> o2) {
				return o1.getKey() > o2.getKey() ? 1 : -1;
			}
		}).getKey();
		return key;
	}

	public void deleteWish(Integer wishId) {
		System.out.println("--------------"+wishlistMap.get(wishId));
		if (wishlistMap.size() > 0 && wishlistMap.get(wishId) != null) {
			Wish deleteWish = wishlistMap.get(wishId);
			deleteWish.setActive(false);
			wishlistMap.put(wishId, deleteWish);
		} else {
			System.out.println("We can not delete");
		}

	}

	public boolean getValidateUser(String userName) {
		System.out.println("DB Service User register Info");
		UserInfo userInfo = userRegisterMap.get(userName);
		return false;
	}

}
