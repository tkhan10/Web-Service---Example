/**
 * 
 */
package com.tofek.db.DBWishlist.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tofek.db.DBWishlist.model.Wish;
import com.tofek.db.DBWishlist.service.DBWishlistService;

/**
 * @author tkhan26
 *
 */
@RestController
public class DBWishlistController {

	DBWishlistService dbWishService = new DBWishlistService();

	@GetMapping("/wishlist")
	public List<Wish> getWishList() {
		System.out.println("DB COntroller ");
		return dbWishService.getWishlist();
	}
	
	@PostMapping(value = "/addWish", consumes = "application/json", produces = "application/json")
	public void addWish(@RequestBody Wish wish) {
		System.out.println("DB Add wish COntroller "+wish.getWishName());
		dbWishService.addWish(wish);
	}
	
	@DeleteMapping("/deleteWish/{wishId}")
	public void deleteWish(@PathVariable("wishId") int wishId) {
		System.out.println("DB delete wish COntroller "+wishId);
		dbWishService.deleteWish(wishId);
	}
	
	@GetMapping("/validateUser/{userName}")
	public boolean validateUser(@PathParam("userName") String userName) {
		System.out.println("validate user DB COntroller ");
		return dbWishService.getValidateUser(userName);
	}

}
