/**
 * 
 */
package com.tofek.db.DBWishlist.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.format.datetime.DateFormatter;

import com.tofek.db.DBWishlist.model.Wish;

/**
 * @author tkhan26
 *
 */
public class ExcelUtils {
	
	 private static final DateTimeFormatter dateFormatter 
		= DateTimeFormatter.ofPattern("yyyy-mm-dd");

	public Workbook getWorkbook() {
		Workbook workbook = null;
		try {
			String excelFilePath = "WishlistApplication.xlsx";
			FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
			try {
				workbook = WorkbookFactory.create(inputStream);
			} catch (InvalidFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Workbook " + workbook.getSheetName(0));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return workbook;
	}

	public void addWishIntoList(Wish wish) {
		try {
			String excelFilePath = "WishlistApplication.xlsx";
			FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
			Workbook workbook = WorkbookFactory.create(inputStream);
			System.out.println("Excel Utils Add methods" + workbook.getSheetName(1));
			int rowCount = workbook.getSheetAt(1).getLastRowNum();

			Object[][] bookData = { {wish.getWishName(), wish.getStartDate(), wish.getEndDate(), 'Y' } };
			Sheet sheet = workbook.getSheet("Wishlist");

			for (Object[] aBook : bookData) {

				Row row = sheet.createRow(++rowCount);
				int columnCount = 0;
				Cell cell = row.createCell(columnCount);
				cell.setCellValue(rowCount);
				for (Object field : aBook) {
					cell = row.createCell(++columnCount);
					if (field instanceof String) {
						cell.setCellValue(field.toString());
					} else if (field instanceof Integer) {
						cell.setCellValue((Integer) field);
					}else if (field instanceof Date) {
						cell.setCellValue((Date)field);
					}
				}
			}
			FileOutputStream out =  new FileOutputStream(new File(excelFilePath));
	        workbook.write(out);
			inputStream.close();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 

	}

	public void getWishIntoList() {

		try {
			ExcelUtils excel = new ExcelUtils();
			Workbook workbook = excel.getWorkbook();
			System.out.println("Excel Utils Add methods" + workbook.getSheet("Wishlist"));
			Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						System.out.print(cell.getNumericCellValue() + "------Numeric");
						break;
					case Cell.CELL_TYPE_STRING:
						System.out.print(cell.getStringCellValue() + "-------String");
						break;
					}
				}
				System.out.println("");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void updateWishIntoList() {

	}

	public void deleteWishFromList() {

	}
}
