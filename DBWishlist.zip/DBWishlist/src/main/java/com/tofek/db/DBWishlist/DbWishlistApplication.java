package com.tofek.db.DBWishlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbWishlistApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbWishlistApplication.class, args);
	}

}
